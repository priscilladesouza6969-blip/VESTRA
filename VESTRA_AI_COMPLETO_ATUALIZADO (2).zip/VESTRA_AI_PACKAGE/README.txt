VESTRA AI — pacote para Vercel

1. Coloque o conteúdo desta pasta no projeto que será publicado na Vercel.
2. A página principal é index.html.
3. A rota /api/stylist usa a OpenAI Responses API.
4. Na Vercel, crie a variável de ambiente OPENAI_API_KEY (Production, Preview se desejar).
5. Opcional: VESTRA_AI_MODEL=gpt-5.6-luna.
6. NÃO coloque OPENAI_API_KEY dentro do HTML.

O orb abre um painel elegante com:
- ligar/desligar microfone;
- escolha de voz;
- parar fala;
- controle por voz do closet, páginas, criador de looks e provador.

A IA recebe o closet e as preferências da conta e devolve ações estruturadas que o navegador executa.
