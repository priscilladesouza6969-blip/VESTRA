const OPENAI_URL = 'https://api.openai.com/v1/responses';

function json(res, status, body) {
  res.status(status).json(body);
}

const schema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    reply: { type: 'string' },
    actions: {
      type: 'array',
      maxItems: 6,
      items: {
        type: 'object',
        additionalProperties: false,
        properties: {
          type: { type: 'string', enum: ['open_view','filter_closet','favorite_piece','create_look','start_fitting','clear_look','save_look'] },
          view: { anyOf: [{ type: 'string', enum: ['home','closet','fitting','look','stylist','measures','plans','profile','beauty'] }, { type: 'null' }] },
          query: { anyOf: [{ type: 'string' }, { type: 'null' }] },
          category: { anyOf: [{ type: 'string' }, { type: 'null' }] },
          pieceIds: { type: 'array', items: { type: 'string' } }
        },
        required: ['type','view','query','category','pieceIds']
      }
    }
  },
  required: ['reply','actions']
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });
  if (!process.env.OPENAI_API_KEY) return json(res, 500, { error: 'OPENAI_API_KEY não configurada na Vercel.' });

  try {
    const body = req.body || {};
    const message = String(body.message || '').trim();
    if (!message) return json(res, 400, { error: 'Mensagem vazia.' });

    const closet = Array.isArray(body.closet) ? body.closet.slice(0, 60) : [];
    const profile = body.profile || {};
    const history = Array.isArray(body.history) ? body.history.slice(-12) : [];

    const instructions = `Você é a VESTRA AI, a assistente pessoal de moda dentro de um guarda-roupa digital. Fale em português do Brasil, de forma natural, curta e amigável.

Você pode conversar e também CONTROLAR a interface VESTRA. Quando o pedido exigir uma ação, coloque a ação em actions. Nunca diga que executou algo se não houver uma ação correspondente.

Ações disponíveis:
- open_view: abrir uma página (home, closet, fitting, look, stylist, measures, plans, profile, beauty).
- filter_closet: abrir o closet e filtrar por query/categoria.
- favorite_piece: favoritar/desfavoritar peças pelos IDs em pieceIds; use apenas IDs existentes.
- create_look: criar um look usando pieceIds existentes.
- start_fitting: abrir o provador e selecionar pieceIds existentes.
- clear_look: limpar o criador de looks.
- save_look: salvar o look atual.

Se a pessoa disser “abre meu closet”, use open_view closet. Se pedir “mostra minhas jaquetas pretas”, use filter_closet com query/categoria. Se pedir para experimentar peças, use start_fitting. Se pedir para montar um look, escolha peças coerentes do closet e use create_look.

Não invente IDs. Se não houver peças suficientes, explique isso e não crie ação inválida.

Preferências aprendidas: ${JSON.stringify(profile.styleMemory || {})}
Medidas: ${JSON.stringify(profile.measures || {})}
Closet disponível: ${JSON.stringify(closet)}
Histórico recente: ${JSON.stringify(history)}
`;

    const response = await fetch(OPENAI_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.VESTRA_AI_MODEL || 'gpt-5.6-luna',
        store: false,
        instructions,
        input: message,
        text: {
          format: {
            type: 'json_schema',
            name: 'vestra_control',
            strict: true,
            schema
          }
        }
      })
    });

    const data = await response.json();
    if (!response.ok) return json(res, response.status, { error: data?.error?.message || 'Erro na OpenAI.' });

    let parsed;
    try {
      parsed = JSON.parse(data.output_text || '{}');
    } catch (_) {
      parsed = { reply: data.output_text || 'Não consegui interpretar essa resposta.', actions: [] };
    }

    return json(res, 200, { reply: parsed.reply || 'Como posso ajudar?', actions: Array.isArray(parsed.actions) ? parsed.actions : [] });
  } catch (error) {
    return json(res, 500, { error: error?.message || 'Erro interno.' });
  }
}
